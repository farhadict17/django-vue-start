var app = new Vue({
    el: '#app',
    data: {
        message: "Hello World!",
        value: 5,
        imgSrc: "https://cdn.pixabay.com/photo/2011/12/14/12/23/solar-system-11111_960_720.jpg",
        link: "https://vuejs.org"
    }
})