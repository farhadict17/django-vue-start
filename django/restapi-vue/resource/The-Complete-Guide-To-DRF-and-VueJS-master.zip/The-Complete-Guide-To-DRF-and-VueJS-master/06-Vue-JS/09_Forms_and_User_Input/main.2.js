var app = new Vue({
    el: "#app",
    data: {
        text: '',
        checked: true,
        city: ''
    }
}) 