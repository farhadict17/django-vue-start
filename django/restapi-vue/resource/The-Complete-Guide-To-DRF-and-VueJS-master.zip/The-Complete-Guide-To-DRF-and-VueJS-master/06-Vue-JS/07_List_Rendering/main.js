var app = new Vue({
    el: "#app",
    data: {
        users: [{
            id: 567,
            name: "alice",
            profession: "developer"
        },
        {
            id: 568,
            name: "bob",
            profession: "developer"
        },
        {
            id: 569,
            name: "batman",
            profession: "manager"
        },
        {
            id: 570,
            name: "robin",
            profession: "designer"
        }, 
        {
            id: 571,
            name: "superman",
            profession: "developer"
        }]
    }
}) 

