from django.contrib import admin
from ebooks.models import Ebook, Review

admin.site.register(Ebook)
admin.site.register(Review)
